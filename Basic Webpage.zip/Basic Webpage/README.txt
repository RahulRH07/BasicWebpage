This is a responsive website.

Here image changes whenever refreshed.

Just its a basic page using anchor tags.

This is made with the help of Tailwind CSS CDN and Tailblocks.